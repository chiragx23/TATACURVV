// const galleryContainer = document.querySelector('.gallery-container');
// const galleryControlsContainer = document.querySelector('.gallery-controls');
// const galleryControls = ['previous','next'];
// const galleryItems = document.querySelectorAll('.gallery-item');


// class Carousel {
//     constructor(conatiner, items, controls){
//         this.carouselContainer = conatiner;
//         this.carouselControls = controls;
//         this.carouselArray = [...items];
//     }

//     updateGallery(){
//         this.carouselArray.forEach(el =>{
//             el.classList.remove('gallery-item-1');
//             el.classList.remove('gallery-item-2');
//             el.classList.remove('gallery-item-3');
//             el.classList.remove('gallery-item-4');
//             el.classList.remove('gallery-item-5');
            
//         })

//         this.carouselArray.slice(0,5),forEach((el , i) => {
//             el.classList.add('gallery-item-${i+1}');
//         });
//     }
//     setCurrentState(direction){
//         if (direction.className == 'gallery-controls-previous'){
//             this.carouselArray.unshift(this.carouselArray.pop());
//         }else{
//             this.carouselArray.push(this.carouselArray.shift());
//         }
//         this.updateGallery();
//     }

//     setControls(){
//         this.carouselControls.forEach(control => {
//             galleryControlsContainer.appendChild(document.createElement('button')).className ='.gallery-controls-${control}';
//             document.querySelector('.gallery-controls-${control}').innerText = control;
//         });
//     }

//     useControls(){
//         const triggers = [...galleryControlsContainer.childNodes];
//         triggers.forEach(control => {
//             control.addEventListener('click', e => {
//                 e.preventDefault();
//                 this.setCurrentState(control);
//             });
//         });
//     }
    
// }

// const exampleCarousel = new Carousel(galleryContainer,galleryItems,galleryControls);

// exampleCarousel.setControls();
// exampleCarousel.useControls();


const galleryContainer = document.querySelector('.gallery-container');
const galleryControlsContainer = document.querySelector('.gallery-controls');
const galleryItems = document.querySelectorAll('.gallery-item');
const galleryControls = ['previous', 'next'];

class Carousel {
  constructor(container, items, controls) {
    this.carouselContainer = container;
    this.carouselControls = controls;
    this.carouselArray = [...items];
  }

  // Update gallery item positions
  updateGallery() {
    this.carouselArray.forEach((el, i) => {
      el.classList.remove(
        'gallery-item-1',
        'gallery-item-2',
        'gallery-item-3',
        'gallery-item-4',
        'gallery-item-5'
      );
      el.classList.add(`gallery-item-${i + 1}`);
    });
  }

  // Set the current state based on button clicks
  setCurrentState(direction) {
    if (direction.classList.contains('gallery-controls-previous')) {
      this.carouselArray.unshift(this.carouselArray.pop());
    } else {
      this.carouselArray.push(this.carouselArray.shift());
    }
    this.updateGallery();
  }

  // Create control buttons dynamically
  setControls() {
    this.carouselControls.forEach((control) => {
      const button = document.createElement('button');
      button.className = `gallery-controls-${control}`;
      button.innerText = control;
      galleryControlsContainer.appendChild(button);
    });
  }

  // Attach click events to the buttons
  useControls() {
    const triggers = [...galleryControlsContainer.childNodes];
    triggers.forEach((control) => {
      control.addEventListener('click', (e) => {
        e.preventDefault();
        this.setCurrentState(control);
      });
    });
  }
}

// Initialize the carousel
const exampleCarousel = new Carousel(galleryContainer, galleryItems, galleryControls);

exampleCarousel.setControls();
exampleCarousel.useControls();